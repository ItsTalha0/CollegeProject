﻿Public Class Form2

    Dim User As String
    Dim password As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text <> "" And TextBox2.Text <> "" Then
            Dim useras As String = TextBox1.Text
            Dim pass As String
            Dim dt As DataTable
            dt = Form1.req(String.Format("SELECT * FROM users WHERE username = '{0}'", useras))


            If dt.Rows.Count > 0 Then
                pass = dt(0)(2)
                If TextBox1.Text = useras And TextBox2.Text = pass Then
                    Form1.Activate()
                    Form1.Show()

                    If useras = "admin" Then
                        Form1.ad = True
                    End If
                    Me.Hide()
                Else
                    MsgBox("Incorect password or UserName Please Try again")
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                End If
            Else
                MsgBox("User Not found")
            End If

        Else
            MsgBox("Please Enter Password and UserName")
            TextBox1.Text = ""
            TextBox2.Text = ""

        End If




    End Sub

End Class