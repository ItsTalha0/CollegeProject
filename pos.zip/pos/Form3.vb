﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = Form1.TextBox3.Text
        TextBox2.Text = Form1.TextBox4.Text
    End Sub


End Class