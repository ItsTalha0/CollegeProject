﻿Imports Npgsql


Public Class Form1

    Public myConnection As NpgsqlConnection = New NpgsqlConnection()
    Dim myCommand As NpgsqlCommand
    Dim mySQLString As String
    Dim constring As String = "Server=free-tier12.aws-ap-south-1.cockroachlabs.cloud;Port=26257;Database=mud-cricket-290.defaultdb;User Id=goprog;Password=CPDuT9uWF2nRxSNcVquDYg;"
    Public ad As Boolean = False
    Public Function req(e As String)
        Dim da As NpgsqlDataAdapter
        Dim dt As New DataTable
        myConnection.ConnectionString = constring
        myConnection.Open()
        mySQLString = e
        myCommand = New NpgsqlCommand(mySQLString, myConnection)
        da = New NpgsqlDataAdapter
        da.SelectCommand = myCommand
        da.Fill(dt)
        myConnection.Close()
        Return dt


    End Function

    Sub ClearAll()
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Sub clearEverything()
        TextBox3.Clear()
        TextBox4.Clear()
        DataGridView1.Rows.Clear()


        ClearAll()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        clearEverything()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Dim da As NpgsqlDataAdapter
        Dim dt As New DataTable
        'myConnection.ConnectionString = constring
        'myConnection.Open()

        If TextBox1.Text <> "" And TextBox2.Text <> "" Then
            'mySQLString = String.Format("SELECT * FROM inventory_text WHERE id={0};", TextBox1.Text)
            'myCommand = New NpgsqlCommand(mySQLString, myConnection)
            'da = New NpgsqlDataAdapter
            'da.SelectCommand = myCommand
            'da.Fill(dt)
            dt = req(String.Format("SELECT * FROM inventory_text WHERE id={0};", TextBox1.Text))
            If dt.Rows.Count > 0 Then
                Dim rowId As Integer = DataGridView1.Rows.Add()
                Dim row As DataGridViewRow = DataGridView1.Rows(rowId)
                row.Cells("Column1").Value = TextBox1.Text

                row.Cells("Column2").Value = dt(0)(1)
                row.Cells("Column3").Value = dt(0)(2)
                row.Cells("Column4").Value = TextBox2.Text
                row.Cells("Column5").Value = Convert.ToInt32(TextBox2.Text) * Convert.ToInt32(dt(0)(2))
                If TextBox3.Text <> "" Then
                    TextBox3.Text = Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox3.Text)
                    TextBox4.Text = Convert.ToInt32(TextBox4.Text) + Convert.ToInt32(TextBox2.Text) * Convert.ToInt32(dt(0)(2))
                Else
                    TextBox3.Text = "0"
                    TextBox3.Text = Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox3.Text)
                End If
            Else
                    MsgBox("ItemNOtFOundError")
            End If

        Else

            MsgBox("Please Enter Barcode And quantity")
        End If

        ClearAll()
    End Sub
    'this is a feature to be added.

    


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Confirm The Bill")
        Dim mobNumber As String
        mobNumber = InputBox("Enter Customers Mobile Number")
        Form3.Show()
        clearEverything()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("You are about to close the application")
        Me.Close()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox3.Text = "0"
        TextBox4.Text = "0"
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click

        TextBox3.Text = TextBox3.Text - 1
        TextBox4.Text = TextBox4.Text - DataGridView1.SelectedRows(0).Cells("Column5").Value
        DataGridView1.Rows.Remove(DataGridView1.SelectedRows(0))

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If ad = True Then
            Form5.Activate()
            Form5.Show()
        Else
            MsgBox("NO administrative Privilages , Login as a admin to make changes")
        End If

    End Sub
End Class
