﻿Public Class Form4
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.req((String.Format("DELETE FROM inventory_text WHERE id={0};", TextBox1.Text)))
    End Sub
End Class