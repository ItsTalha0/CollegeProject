﻿Public Class Form5
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dt As DataTable
        dt = Form1.req(String.Format("DELETE FROM inventory_text WHERE id={0};", TextBox1.Text))
        MsgBox("Removal Succesfull")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim dt As DataTable
        Form1.req(String.Format("INSERT INTO inventory_text (id,""Name"",""UnitPrice"") VALUES ({0},'{1}',{2});", TextBox2.Text, TextBox3.Text, TextBox4.Text))
        MsgBox("Product add successfull")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim dt As DataTable
        dt = Form1.req(String.Format("SELECT id,""Name"",""UnitPrice"" FROM inventory_text;", TextBox2.Text, TextBox3.Text, TextBox4.Text))
        DataGridView1.DataSource = dt
    End Sub
End Class